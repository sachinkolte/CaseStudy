﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MvcApplication1.Models;
namespace MvcApplication1.Controllers
{
    public class ProjectsController : ApiController
    {
         DataLayer _context =new DataLayer();
    
       [HttpGet]
        public string GetProject(string param1)
        {

            string str = _context.GetDatatableJSon("GetProject", "");
            return str;
        }
        

        [HttpPost]
        public string SaveProject(HttpRequestMessage request, [FromBody] DataLayer.CommonClasss obj)
        {
            return _context.Returnsavexml("SaveProject", obj.FilterParameter);
            
        }
    
        public HttpResponseMessage Delete(int id)
        {
            _context.DeleteRecord("DeleteProject", id);
            return Request.CreateResponse(HttpStatusCode.OK, id);
        }
        [HttpGet]
        public HttpResponseMessage SuspendProject(int id)
        {
            _context.DeleteRecord("SuspendProject", id);
            return Request.CreateResponse(HttpStatusCode.OK, id);
        }
      
      

    }
    
}
