﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication1.Controllers
{
    public class TaskController : Controller
    {
        //
        // GET: /Task/

        public ActionResult Index(int id)
        {
            return View();
        }

        public ActionResult ViewTask()
        {
            return View();
        }
    }
}
