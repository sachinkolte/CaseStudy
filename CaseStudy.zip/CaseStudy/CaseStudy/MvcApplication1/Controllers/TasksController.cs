﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MvcApplication1.Models;
namespace MvcApplication1.Controllers
{
    public class TasksController : ApiController
    {
        DataLayer _context = new DataLayer();

        [HttpGet]
        public string GetTask(string param1)
        {

            string str = _context.GetDatatableJSon("GetTask", "");
            return str;
        }


        [HttpPost]
        public string SaveTask(HttpRequestMessage request, [FromBody] DataLayer.CommonClasss obj)
        {
            return _context.Returnsavexml("SaveTask", obj.FilterParameter);

        }

        public HttpResponseMessage Delete(int id)
        {
            _context.DeleteRecord("DeleteTask", id);
            return Request.CreateResponse(HttpStatusCode.OK, id);
        }

        public string GetTaskById(string id)
        {

            string str = _context.getjsondata("GetTaskById", id);
            return str;
        }
    }
}
