﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MvcApplication1.Models;
namespace MvcApplication1.Controllers
{
    public class UsersController : ApiController
    {
        DataLayer _context =new DataLayer();
    
       [HttpGet]
        public string GetUser(string param1)
        {

            string str = _context.GetDatatableJSon("GetUser", "");
            return str;
        }
        

        [HttpPost]
        public string SaveUser(HttpRequestMessage request, [FromBody] DataLayer.CommonClasss obj)
        {
            return _context.Returnsavexml("SaveUser", obj.FilterParameter);
            
        }
    
        public HttpResponseMessage Delete(int id)
        {
            _context.DeleteRecord("DeleteUser", id);
            return Request.CreateResponse(HttpStatusCode.OK, id);
        }  
    }
}
