﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using Newtonsoft.Json;
namespace MvcApplication1.Models
{
    public class DataLayer
    {
        public class CommonClasss
        {
            public string FirstName { get; set; }
            public string SecondName { get; set; }
            public string FilterParameter { get; set; }
            public string Type { get; set; }
            public string result { get; set; }
            public string xml { get; set; }

            public SecondGet SecondGet;
        }

        public class SecondGet
        {
            public string Mobile { get; set; }
            public string EmailId { get; set; }
        }
        public string SaveJson(string proc, string json)
        {
            using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString))
            {
                conn.Open();
                SqlCommand sqlComm = new SqlCommand(proc, conn);
                sqlComm.CommandType = CommandType.StoredProcedure;
                if (json != "" && json != null)
                {
                    var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
                    foreach (var kv in dict)
                    {
                        string value = kv.Value;
                        sqlComm.Parameters.AddWithValue("@" + kv.Key, value);
                    }

                }
                int i = 0;
                i = sqlComm.ExecuteNonQuery();
                conn.Close();
                try
                {
                    if (i > 0)
                    {
                        // return ("{'status':'1'}");
                        return "status1";

                    }
                    else
                    {
                        return ("{'status':'0'}");
                    }
                }
                catch
                {

                    return ("{'status':'0'}");
                }
            }


        }
        public string Returnsavexml(string proc, string json)
        {
            DataSet ds = new DataSet("data1");
            XmlDocument doc = new XmlDocument();
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString))
            {
                string query = proc;
                SqlCommand cmd = new SqlCommand(query);
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                if (json != "")
                {
                    doc = (XmlDocument)JsonConvert.DeserializeXmlNode("{'root':{'subroot':" + json + " }}");
                    cmd.Parameters.AddWithValue("@xml", doc.InnerXml.ToString());
                }
              
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(ds);
                try
                {
                    if (ds.Tables.Count == 0)
                    { return ""; }
                    else
                    {
                        return JsonConvert.SerializeObject(ds.Tables[0]);
                    } 
                }
                catch
                {

                    return "Error";
                }
            }

        }
        public string savexml(string proc, string json)
        {

            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString))
            {
                string query = proc;
                SqlCommand cmd = new SqlCommand(query);
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                XmlDocument doc = (XmlDocument)JsonConvert.DeserializeXmlNode("{'root':{'subroot':" + json + " }}");
                cmd.Parameters.AddWithValue("@xml", doc.InnerXml.ToString());
                int i = 0;
                i = cmd.ExecuteNonQuery();

                try
                {
                    if (i > 0)
                    {
                        // return ("{'status':'1'}");
                        return "status1";

                    }
                    else
                    {
                        return ("{'status':'0'}");
                    }
                }
                catch
                {

                    return ("{'status':'0'}");
                }


            }



        }
        public string GetDatatableJSon(string proc, string json)
        {
            DataSet ds = new DataSet("data1");
            XmlDocument doc = new XmlDocument();
            using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString))
            {
                SqlCommand sqlComm = new SqlCommand(proc, conn);
                sqlComm.CommandType = CommandType.StoredProcedure;
                if (json != "" && json != null)
                {
                    var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
                    foreach (var kv in dict)
                    {
                        string value = kv.Value;
                        sqlComm.Parameters.AddWithValue("@" + kv.Key, value);
                    }

                }
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlComm;
                da.Fill(ds);


            }
            return JsonConvert.SerializeObject(ds.Tables[0]);
        }
        public string DeleteRecord(string proc, int Id)
        {

            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString))
            {
                con.Open();
                SqlCommand scmd = new SqlCommand(proc, con);
                scmd.Parameters.AddWithValue("@Id", Id);
                scmd.CommandType = CommandType.StoredProcedure;
           
                int i = 0;
                i = scmd.ExecuteNonQuery();
                con.Close();
                try
                {
                    if (i > 0)
                    {
                        // return ("{'status':'1'}");
                        return "status1";

                    }
                    else
                    {
                        return ("{'status':'0'}");
                    }
                }
                catch
                {

                    return ("{'status':'0'}");
                }
            }
            

        }


        public string getjsondata(string proc, string Id)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString))
            {
                string query = proc;
                SqlCommand cmd = new SqlCommand(query);
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@Id" , Id);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(ds);
            }
            return JsonConvert.SerializeObject(ds.Tables[0]);
        }
    }


}