﻿var app = angular.module('ProjectManager', []);
app.service('API', ['$http', function ($http, $scope) {
    this.Get = function (url, obj) {
        return $http({
            url: url,
            dataType: 'json',
            method: 'Get',
            params: { param1: angular.toJson(obj, false) },
            headers: {
                "Content-Type": "application/json"
            }
        });
    };

    this.Post = function (url, obj) {
        return $http({
            url: url,
            dataType: 'json',
            method: 'POST',
            data: angular.toJson(obj, false),
            headers: {
                "Content-Type": "application/json"
            }
        });
    };
    this.Delete = function (url, Id) {
        return $http.delete(url + "/" + Id)
    };
    this.GetById = function (url, Id) {
        return $http({
            url: url + "/" + Id,
            dataType: 'json',
            method: 'Get',
            headers: {
                "Content-Type": "application/json"
            }
        });

    };
}]);
app.controller('MainController', ['$http', '$scope', '$sce', function ($http, $scope, $sce) {
 
}]);
app.controller('UserCtrl', ['$http', '$scope', '$sce', 'API', function ($http, $scope, $sce, API) {
    
    GetUser();
    function GetUser() {
        API.Get("/api/Users/GetUser", "").then(function (response) {
            $scope.UserData = angular.fromJson(response.data);
        }, function (error) {
        });

    }
    $scope.AddUser = function () {
        $scope.UserId = 0;
        $scope.FirstName = '';
        $scope.LastName = '';
        $scope.EmployeeID = '';

    }
    $scope.EditUser = function (user, index) {
        $scope.index = index;
        $scope.UserId = user.User_ID;
        $scope.FirstName = user.FirstName;
        $scope.LastName = user.LastName;
        $scope.EmployeeID = user.Employee_ID;
       
    }
    

    $scope.SaveUser = function () {
        var obj = new Object();
        obj.FilterParameter = angular.toJson({
            FirstName: $scope.FirstName,
            LastName: $scope.LastName,
            EmployeeID: $scope.EmployeeID,
            UserId:$scope.UserId
        }, false);
     
        API.Post("/api/Users/SaveUser", obj).then(function (response) {
           var Result = angular.fromJson(response.data);
           if ($scope.UserId != 0) {
               $scope.UserData[$scope.index] = Result[0];
               $.bootstrapGrowl("User Updated", {
                   type: 'success '
               });
           } else {
               $scope.UserData.push(Result[0]);
               $.bootstrapGrowl("User Saved", {
                   type: 'success '
               });
           }
           jQuery("#UserModal").modal("hide");
          
        }, function (error) {
        });
    }
    $scope.DeleteUser = function (User,Index) {
        API.Delete("/api/Users/Delete", User.User_ID).then(function (response) {
            $scope.UserData.splice(Index, 1);
            $.bootstrapGrowl("User Delete", {
                type: 'success '
            });
        }, function (error) {
        });
    }
   
   
}]);
app.controller('ProjectCtrl', ['$http', '$scope', '$sce', 'API', function ($http, $scope, $sce, API) {
    GetProject();
    function GetProject() {
        API.Get("/api/Projects/GetProject", "").then(function (response) {
            $scope.ProjectData = angular.fromJson(response.data);
        }, function (error) {
        });

    }
    GetUser();
    function GetUser() {
        API.Get("/api/Users/GetUser", "").then(function (response) {
            $scope.UserData = angular.fromJson(response.data);
        }, function (error) {
        });

    }
    $scope.CloseUserModal = function () {
        jQuery("#UserModal").modal("hide");
    }

    $scope.SelectManager = function (User) {
        $scope.Manager = User.FirstName + ' ' + User.LastName;
        $scope.ManagerId = User.User_ID;
        jQuery("#UserModal").modal("hide");
    }

    $scope.AddProject = function () {
        $scope.ProjectId = 0;
        $scope.Project = '';
        $scope.IsDates = false;
        $scope.FromDate = '';
        $scope.ToDate = '';
        $scope.Priority = 0;
        $scope.Manager = '';
        $scope.ManagerId = '';
        $scope.Status = '';
    }
    $scope.UpdateProject = function (Project, index) {
        $scope.index = index;
        $scope.ProjectId = Project.Project_ID;
        $scope.Project = Project.Project;
        $scope.IsDates = Project.IsDates;
        $scope.FromDate = new Date(Project.StartDate);
        $scope.ToDate = new Date(Project.EndDate);
        $scope.Priority = Project.Priority;
        $scope.Manager = Project.Manager;
        $scope.ManagerId = Project.ManagerId;
        $scope.Status = Project.status;
        jQuery("#ProjectModal").modal("show");
    }


    $scope.SaveProject= function () {
        var obj = new Object();
        obj.FilterParameter = angular.toJson({
            Project: $scope.Project,
            IsDates: $scope.IsDates,
            FromDate: $scope.IsDates==true ?  $scope.FromDate : '',
            ToDate:  $scope.IsDates==true ?  $scope.ToDate : '', 
            Priority: $scope.Priority,
            ManagerId:$scope.ManagerId,
            ProjectId: $scope.ProjectId,
            Status: $scope.Status,
        }, false);

        API.Post("/api/Projects/SaveProject", obj).then(function (response) {
            var Result = angular.fromJson(response.data);
            GetProject();
            if ($scope.UserId != 0) {
               // $scope.ProjectData[$scope.index] = Result[0];
                $.bootstrapGrowl("Project Updated", {
                    type: 'success '
                });
            } else {
               // $scope.ProjectData.push(Result[0]);
                $.bootstrapGrowl("Project Saved", {
                    type: 'success '
                });
            }
            jQuery("#ProjectModal").modal("hide");

        }, function (error) {
        });
    }
    $scope.DeleteProject = function (User, Index) {
        API.Delete("/api/Projects/Delete", User.Project_ID).then(function (response) {
            $scope.ProjectData.splice(Index, 1);
            $.bootstrapGrowl("Project Delete", {
                type: 'success '
            });
        }, function (error) {
        });
    }
    $scope.SuspendProject = function (User, Index) {
        API.GetById("/api/Projects/SuspendProject", User.Project_ID).then(function (response) {
            GetProject();
        }, function (error) {
        });
    }
    

}]);
app.controller('TaskCtrl', ['$http', '$scope', '$sce', 'API', function ($http, $scope, $sce, API) {
    var url = document.URL;
    $scope.TaskId = url.substring(url.lastIndexOf('/') + 1);
    $scope.StartDate = new Date();
    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var date = new Date()
    $scope.EndDate = tomorrow;
    $scope.TaskParentId = 0;
    GetTaskById();
    GetProject();

    function GetTaskById() {
        API.GetById("/api/Tasks/GetTaskById", $scope.TaskId).then(function (response) {
            $scope.TaskData = angular.fromJson(response.data);

            $scope.Project = $scope.TaskData[0].Project;
            $scope.Task=$scope.TaskData[0].Task;
            $scope.IsParentTask = $scope.TaskData[0].Parent_ID == 0 ? false : true;
            $scope.StartDate = $scope.TaskData[0].StartDate;
            $scope.EndDate = $scope.TaskData[0].EndDate;
            $scope.Priority = $scope.TaskData[0].Priority;
            $scope.UserId = $scope.TaskData[0].Userid;
            $scope.ParentTask = $scope.TaskData[0].ParentTask;
            $scope.User = $scope.TaskData[0].Manager;
            $scope.ProjectId = $scope.TaskData[0].Project_ID;
            $scope.TaskId = $scope.TaskData[0].Task_ID;
            $scope.TaskParentId = $scope.TaskData[0].Parent_ID;
        }, function (error) {
        });
    }


    function GetProject() {
        API.Get("/api/Projects/GetProject", "").then(function (response) {
            $scope.ProjectData = angular.fromJson(response.data);
        }, function (error) {
        });
    }
    GetUser();
    function GetUser() {
        API.Get("/api/Users/GetUser", "").then(function (response) {
            $scope.UserData = angular.fromJson(response.data);
        }, function (error) {
        });
    }
    ViewTask();
    function ViewTask() {
        API.Get("/api/Tasks/GetTask", "").then(function (response) {
            $scope.TasksData = angular.fromJson(response.data);
        }, function (error) {
        });
    }

    $scope.CloseUserModal = function () {
        jQuery("#UserModal").modal("hide");
    }
    $scope.ProjectModal = function () {
        jQuery("#ProjectModal").modal("hide");
    }
    $scope.CloseTaskModal = function () {
        jQuery("#TaskModal").modal("hide");
    }
    
    $scope.SelectManager = function (User) {
        $scope.User = User.FirstName + ' ' + User.LastName;
        $scope.UserId = User.User_ID;
        jQuery("#UserModal").modal("hide");
    }

    $scope.SelectProject = function (Project) {
        $scope.Project = Project.Project;
        $scope.ProjectId = Project.Project_ID;
        jQuery("#ProjectModal").modal("hide");
    }

    $scope.SelectTask = function (Task) {
        $scope.TaskParentId = Task.Task_ID;
        $scope.ParentTask = Task.Task;
        jQuery("#TaskModal").modal("hide");
    }

    $scope.Resettask = function () {
        $scope.Project = '';
        $scope.User = '';
        $scope.Task = '';
        $scope.IsParentTask = false;
         $scope.StartDate = '';
         $scope.EndDate = '';
         $scope.Priority = 0;
         $scope.UserId = 0;
         $scope.ProjectId = 0;
         $scope.TaskId = 0;
         $scope.StartDate = new Date();
         var tomorrow = new Date();
         tomorrow.setDate(tomorrow.getDate() + 1);
         var date = new Date()
         $scope.EndDate = tomorrow;
    }
   
    $scope.SaveTask = function () {
        var obj = new Object();
        obj.FilterParameter = angular.toJson({
            Project: $scope.Project,
            Task: $scope.Task,
            IsParentTask: $scope.IsParentTask,
            StartDate: $scope.StartDate,
            EndDate: $scope.EndDate,
            Priority: $scope.Priority,
            UserId: $scope.UserId,
            ProjectId: $scope.ProjectId,
            TaskId: $scope.TaskId,
            TaskParentId: $scope.TaskParentId
        }, false);

        API.Post("/api/Tasks/SaveTask", obj).then(function (response) {
            var Result = angular.fromJson(response.data);
            if ($scope.TaskId != 0) {
                $.bootstrapGrowl("Project Updated", {
                    type: 'success '
                });
            } else {
                $.bootstrapGrowl("Project Saved", {
                    type: 'success '
                });
            }
        }, function (error) {
        });
    }
    $scope.DeleteProject = function (User, Index) {
        API.Delete("/api/Projects/Delete", User.Project_ID).then(function (response) {
            $scope.ProjectData.splice(Index, 1);
            $.bootstrapGrowl("Project Delete", {
                type: 'success '
            });
        }, function (error) {
        });
    }


}]);
app.controller('ViewTaskCtrl', ['$http', '$scope', '$sce', 'API', function ($http, $scope, $sce, API) {

    $scope.TaskId = 0;
    
    ViewTask();
    function ViewTask() {
        API.Get("/api/Tasks/GetTask", "").then(function (response) {
            $scope.TasksData = angular.fromJson(response.data);
        }, function (error) {
        });

    }



    
   
    $scope.DeleteTask = function (Task, Index) {
        API.Delete("/api/Tasks/Delete", Task.Task_ID).then(function (response) {
            $scope.TasksData.splice(Index, 1);
            $.bootstrapGrowl("Task Deleted", {
                type: 'success '
            });
        }, function (error) {
        });
    }


}]);
$(".txtdate").on("change", function () {
    this.setAttribute(
        "data-date",
        moment(this.value, "YYYY-MM-DD")
        .format(this.getAttribute("data-date-format"))
    )
}).trigger("change")